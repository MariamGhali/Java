package hw3;
/**
 * This class will create the main nodes of the list which are Head Tail and the temp nodes
 * then it will create the insert and and the different type of the sorting methods 
 * @author mariam
 *
 */
public class charLinkedList {
	// public charLinkedList(int n) {
	// // TODO Auto-generated constructor stub
	// int sizeOfLinkedList = n;
	// }
	protected node head;
	protected node tail;
	protected node k;
	protected node l;
	protected node temp;
	/**
	 * get the value from the StackQueueDemo class the one the user wants to insert 
	 * and there is 2 situation if the linkedlist is empty then create a node
	 *  that will hold this value in the data attribute in charNode and assigmen this 
	 *  node to be the head and the tail of the linked list  
	 *  case 2 if the insert at the end make temp = tail and move through the whole linked list 
	 *  until we find the next one is null so we create a node and make it the tail of the new linked lisrt
	 * @param x the value we want to insert in thr linked list 
	 */
	  public void insert(char x) {
	  
		  if (head == null){
				temp = new node(x);
				head = temp;
				tail = temp;
				//if the first node is empty make it as a head 
			}else {
				temp = head;
				while(true){
					if (temp.next == null) {
			            temp.next = new node(x);	//create a noda at the end of the linked list 
			            tail = temp.next;
			            break;
					} else {
						temp = temp.next;		//and if temp is not the last element move to the next node 
					}
				}
		    }
	  }
	/**
	 * it will get the value of the currect node which is head and compare it wit the value of the next node 
	 * and it will be temp.next
	 * if the head value is greate then the next node then swap andirrtate this until the whole linked list is sorted 
	 * call the method sort and special from main to  	  
	 * @param n the size of hte linked list 
	 */
	public void bubbleSort(int n) {
			int sizeOfLinkedList = n;
			int i = 0;
			int j = 0;
			char temp1;
			k = head; // current node
			l = head.next; // next node
				
			if (sizeOfLinkedList > 1) {
				for (i = 0; i < sizeOfLinkedList - 1; i++) {
					for (j = 1; j < sizeOfLinkedList - i; j++) {
						if (k.value > l.value) {
							temp1 = k.value;
							k.value = l.value;
							l.value = temp1	;
						}
						k = k.next;
						l = l.next;

					}
				}
			}
		}
	 
	/*
	public void insert(char x) {
		node temp = new node(x);

		if (head == null) {
			head = temp;
			tail = head;
		} else {
			temp.setNext(head);
			head = temp;
		}
	}*/
/*
	public void bubbleSort(int n) {
		int sizeOfLinkedList = n;
		int i = 0;
		int j = 0;
		char temp1;
	 	/*k = head; // current node
		l = head.next(); // next node
		*/
	/*	if (sizeOfLinkedList > 1) {
			for (i = 0; i < sizeOfLinkedList - 1; i++) {
				for (j = 1; j < sizeOfLinkedList - i; j++) {
					if (getValue(j - 1, n) > getValue(j, n)) {
						temp1 = getValue(j - 1, n);
						getNode(j - 1,  n).setValue(getValue(j, n));
						getNode(j,  n).setValue(temp1);
					}/*
					k = k.next();
					l = l.next();

				}

			}

		}
	}*/

	/*
	 * public void printData() { temp = head; char data; while(temp != null) {
	 * data = temp.value; System.out.println(data); data = temp.next.value;
	 * break; } }
	 * 
	 */
	/*public node getHead() {
		return head;
	}
	
	public node getNode(int pos, int n){
		if ((pos <0) || (pos > n))  return null;
		node temp = head;
		for (int i = 0; i < pos; i++) {
			temp = temp.next();
		}
		return temp;
	}
	
	public char getValue(int pos, int n){
		if ((pos <0) || (pos > n))  return '\0';
		node temp = head;
		for (int i = 0; i < pos; i++) {
			temp = temp.next();
		}
		return temp.value();
	}*/
	/*
	private  node head;
    private int size; 

    public charLinkedList(){
        this.head = null;
        this.size = 0;
    }

    public void add(char data) {
        node node = new node(data);
        if (head == null) {
            head = node;
        } else {
            node currentNode = head;
            while(currentNode.next != null) {
                currentNode = currentNode.next;
            }
            currentNode.next = node;
        }
        size++;     
    }

    public void sort() {
        if (size > 1) {
            for (int i = 0; i < size; i++ ) {
                node currentNode = head;
                node next = head.next;
                for (int j = 0; j < size - 1; j++) {
                    if (currentNode.getValue()> next.getValue()) {
                        node temp = currentNode;
                        currentNode = next;
                        next = temp;
                    } 
                    currentNode = next;
                    next = next.next;                   
                } 
            }
        }
    }

    public int listSize() {     
        return size;
    }

    public void printData() {
        node currentNode = head;
        while(currentNode != null) {
            int data = currentNode.getValue();
            System.out.println(data);
            currentNode = currentNode.next;
        }
    }
    /*
	 private  node head;
	    private int size; 

	    public charLinkedList(){
	        this.head = null;
	        this.size = 0;
	    }

	    public void add(int data) {
	        node node = new node(data);
	        if (head == null) {
	            head = node;
	        } else {
	            node currentNode = head;
	            while(currentNode.nextNode != null) {
	                currentNode = currentNode.nextNode;
	            }
	            currentNode.nextNode = node;
	        }
	        size++;     
	    }

	    public void sort() {
	    	if (size > 1) {
	            for (int i = 0; i < size; i++ ) {
	                node currentNode = head;
	                node next = head.nextNode;
	                for (int j = 0; j < size - 1; j++) {
	                    if (currentNode.data > next.data) {
	                        int temp = currentNode.data;
	                        currentNode.data = next.data;
	                        next.data = temp;
	                    } 
	                    currentNode = next;
	                    next = next.nextNode;                   
	                } 
	            }
	        }
	    }

	    public int listSize() {     
	        return size;
	    }

	    public void printData() {
	        node currentNode = head;
	        while(currentNode != null) {
	            int data = currentNode.getData();
	            System.out.println(data);
	            currentNode = currentNode.nextNode;
	        }
	    }

	    public boolean isEmpty() {
	        return size == 0;
	    }
*/
}
