package BTrees;
/**
 * to get the other three feilds of the ascii table when we create the node 
 * @author mariam
 *
 */
public class RelevantValues {
	
	String val1; 
	String val2;
	String val3;
	/**
	 * Contractor for te other three fields so for example if it is for the decmial tree then 
	 * @param str1 is the hex value 
	 * @param str2 is the oct value 
	 * @param str3 is he char value 
	 */
	public RelevantValues(String str1, String str2, String str3){
		val1 = str1;
		val2 = str2;
		val3 = str3;
	}
}
