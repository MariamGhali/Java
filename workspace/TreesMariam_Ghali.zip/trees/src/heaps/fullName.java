package heaps;
/**
 * this class will help to search based on the last or the first name 
 * @author mariam
 *
 */
public class fullName {

	String firstName;
	String lastName;
	/**
	 *	to get the last and first name for each value in the file 
	 * @param x first name 
	 * @param y last name 
	 *
	 */
	public fullName(String x, String y) {
		firstName= x;
		lastName = y;		
	}
}
